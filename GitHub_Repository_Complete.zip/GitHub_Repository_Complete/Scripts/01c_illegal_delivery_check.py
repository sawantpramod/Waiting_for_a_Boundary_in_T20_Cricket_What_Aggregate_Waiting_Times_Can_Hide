#!/usr/bin/env python
"""
Illegal-Delivery First-Event Check

Outputs (written to OUTPUT_TABLES, same folder as every other script):
    illegal_delivery_first_event_check.csv   -- one row per innings
    illegal_delivery_first_event_summary.csv -- one-row summary for the article

Usage:
    python 01c_illegal_delivery_check.py
"""

import numpy as np
import pandas as pd
from pathlib import Path
from common import OUTPUT_TABLES, load_data


def first_event_full_and_legal(group):
   
    out = {}
    legal_group = group[group["is_legal_delivery"]].reset_index(drop=True)

    for event_name, event_col in [("wicket", "wicket_flag"), ("boundary", "is_boundary_any")]:
        full_idx = np.flatnonzero(group[event_col].to_numpy())
        if len(full_idx):
            first_full_is_illegal = bool(not group.iloc[full_idx[0]]["is_legal_delivery"])
        else:
            first_full_is_illegal = None

        legal_idx = np.flatnonzero(legal_group[event_col].to_numpy())
        legal_recorded = int(legal_idx[0] + 1) if len(legal_idx) else None

        # Affected only if a true first event exists AND it happened on an
        # illegal delivery (so the legal-only search necessarily skips it).
        affected = bool(first_full_is_illegal) if first_full_is_illegal is not None else False

        out[f"first_{event_name}_true_event_on_illegal_delivery"] = first_full_is_illegal
        out[f"first_{event_name}_legal_only_attempt_recorded"] = legal_recorded
        out[f"{event_name}_legal_only_first_is_wrong"] = affected

    return out


def main():
    # Ensure OUTPUT_TABLES directory exists
    OUTPUT_TABLES.mkdir(parents=True, exist_ok=True)
    
    df = load_data()

    # True chronological order per innings -- legal AND illegal deliveries,
    # sorted the same way common.prepare_analysis_view sorts the legal-only
    # view, so the two are directly comparable.
    df = df.sort_values(
        ["match_id", "innings_no", "over_no", "ball_no"], kind="mergesort"
    ).reset_index(drop=True)

    # Same boundary definition as common.py (runs off bat exactly 4 or 6),
    # deliberately NOT restricted to legal deliveries here -- that
    # restriction is exactly what this script is checking.
    df["is_boundary_any"] = df["runs_off_bat"].isin([4, 6])

    records = []
    for (match_id, innings_no), group in df.groupby(
        ["match_id", "innings_no"], sort=False
    ):
        row = {"match_id": match_id, "innings_no": innings_no}
        row.update(first_event_full_and_legal(group))
        records.append(row)

    result = pd.DataFrame(records)
    
    # Save with explicit encoding to avoid Unicode issues
    output_file = OUTPUT_TABLES / "illegal_delivery_first_event_check.csv"
    result.to_csv(output_file, index=False, encoding='utf-8')
    print(f"[OK] Saved: {output_file}")

    n_innings = len(result)
    n_illegal_wickets_total = int(
        df["wicket_flag"].sum() - df.loc[df["is_legal_delivery"], "wicket_flag"].sum()
    )
    n_illegal_boundaries_total = int((df["is_boundary_any"] & ~df["is_legal_delivery"]).sum())

    n_wicket_affected = int(result["wicket_legal_only_first_is_wrong"].sum())
    n_boundary_affected = int(result["boundary_legal_only_first_is_wrong"].sum())

    summary = pd.DataFrame([{
        "total_innings": n_innings,
        "wickets_on_illegal_deliveries_total": n_illegal_wickets_total,
        "boundary_value_shots_on_illegal_deliveries_total": n_illegal_boundaries_total,
        "innings_where_legal_only_first_wicket_is_wrong": n_wicket_affected,
        "innings_where_legal_only_first_boundary_is_wrong": n_boundary_affected,
    }])
    
    summary_file = OUTPUT_TABLES / "illegal_delivery_first_event_summary.csv"
    summary.to_csv(summary_file, index=False, encoding='utf-8')
    print(f"[OK] Saved: {summary_file}")

    print("\n=== ILLEGAL-DELIVERY FIRST-EVENT CHECK ===")
    print(summary.to_string(index=False))

    if n_wicket_affected:
        print("\nInnings where the legal-only 'first wicket' is not the true first wicket:")
        print(result.loc[
            result["wicket_legal_only_first_is_wrong"],
            ["match_id", "innings_no", "first_wicket_legal_only_attempt_recorded"]
        ].to_string(index=False))

    if n_boundary_affected:
        print("\nInnings where the legal-only 'first boundary' is not the true first boundary:")
        print(result.loc[
            result["boundary_legal_only_first_is_wrong"],
            ["match_id", "innings_no", "first_boundary_legal_only_attempt_recorded"]
        ].to_string(index=False))

    print("\nNOTE: This script does not change first_wicket_attempt / first_boundary_attempt")
    print("anywhere else in the pipeline. It only verifies and quantifies how many innings")
    print("are affected by the legal-only event definition, for transparent disclosure.")


if __name__ == "__main__":
    main()