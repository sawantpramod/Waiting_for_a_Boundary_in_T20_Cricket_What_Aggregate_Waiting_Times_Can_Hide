#!/usr/bin/env python
"""
Parametric Bootstrap Calibration of the Chi-Square GOF Test

Outputs:
    parametric_bootstrap_gof_boundary.csv  -- primary result (Comment 8/9)
    parametric_bootstrap_gof_wicket.csv    -- included for completeness only;

Usage:
    python 09b_parametric_bootstrap_gof.py
    python 09b_parametric_bootstrap_gof.py --n-simulations 20000 --seed 42
"""

import argparse
import numpy as np
import pandas as pd
from pathlib import Path
from scipy.stats import chi2

try:
    from common import OUTPUT_TABLES
except ImportError:
    OUTPUT_TABLES = Path("tables")
    print(f"Warning: Using fallback output path: {OUTPUT_TABLES}")

OUTPUT_TABLES.mkdir(parents=True, exist_ok=True)


def chi2_stat_for_sample(waits, p_hat):
   
    waits = np.asarray(waits, dtype=float)
    n = len(waits)
    max_ball = waits.max()

    cutoff = 1
    while cutoff <= max_ball:
        expected_count = n * ((1 - p_hat) ** (cutoff - 1) * p_hat)
        if expected_count < 5:
            break
        cutoff += 1
    cutoff = max(4, cutoff)

    bins = list(range(1, cutoff)) + [cutoff]
    observed_counts = []
    for i in range(len(bins) - 1):
        observed_counts.append(np.sum((waits >= bins[i]) & (waits < bins[i + 1])))
    observed_counts.append(np.sum(waits >= bins[-1]))

    expected_counts = []
    for i in range(len(bins) - 1):
        if bins[i] == 1:
            prob = 1 - (1 - p_hat) ** (bins[i + 1] - 1)
        else:
            prob = (1 - p_hat) ** (bins[i] - 1) - (1 - p_hat) ** (bins[i + 1] - 1)
        expected_counts.append(n * prob)
    expected_counts.append(n * (1 - p_hat) ** (cutoff - 1))

    observed_counts = np.array(observed_counts, dtype=float)
    expected_counts = np.array(expected_counts, dtype=float)
    stat = np.sum((observed_counts - expected_counts) ** 2 / expected_counts)
    df = len(bins) - 2
    return stat, df


def calibrate(observed_waits, event_name, n_simulations, seed):
    observed_waits = np.asarray(observed_waits, dtype=float)
    n_obs = len(observed_waits)
    p_mle_obs = 1.0 / observed_waits.mean()

    obs_stat, obs_df = chi2_stat_for_sample(observed_waits, p_mle_obs)

    rng = np.random.default_rng(seed)
    sim_stats = np.empty(n_simulations)
    sim_dfs = np.empty(n_simulations, dtype=int)
    for i in range(n_simulations):
        sim_waits = rng.geometric(p_mle_obs, size=n_obs)
        p_sim = 1.0 / sim_waits.mean()
        stat, df_ = chi2_stat_for_sample(sim_waits, p_sim)
        sim_stats[i] = stat
        sim_dfs[i] = df_

    empirical_p = float(np.mean(sim_stats >= obs_stat))
    naive_p_lower = float(1 - chi2.cdf(obs_stat, obs_df))
    naive_p_upper = float(1 - chi2.cdf(obs_stat, obs_df + 1))

    print(f"\n{event_name}:")
    print(f"  n innings (observed events): {n_obs}")
    print(f"  p_mle (fit to observed waits): {p_mle_obs:.6f}")
    print(f"  Observed chi2 statistic: {obs_stat:.4f}, df: {obs_df}")
    print(f"  Naive chi2(df) p-value (lower bound):        {naive_p_lower:.4f}")
    print(f"  Chernoff-Lehmann chi2(df+1) p-value (upper):  {naive_p_upper:.4f}")
    print(f"  Parametric bootstrap empirical p-value (n_sim={n_simulations}): {empirical_p:.4f}")
    print(f"  df distribution across replicates: {pd.Series(sim_dfs).value_counts().to_dict()}")

    return {
        "event": event_name,
        "n_innings": n_obs,
        "p_mle": p_mle_obs,
        "chi2_stat": obs_stat,
        "df": obs_df,
        "naive_p_lower_chi2_df": naive_p_lower,
        "naive_p_upper_chi2_df_plus_1": naive_p_upper,
        "bootstrap_empirical_p": empirical_p,
        "n_simulations": n_simulations,
        "seed": seed,
    }


def main():
    parser = argparse.ArgumentParser(
        description="Parametric bootstrap calibration of the boundary/wicket "
                     "chi-square GOF tests (publisher Comment 8/9)."
    )
    parser.add_argument("--n-simulations", type=int, default=20000,
                         help="Number of bootstrap replicates (default: 20000)")
    parser.add_argument("--seed", type=int, default=42,
                         help="Random seed for reproducibility (default: 42)")
    args = parser.parse_args()

    innings_df = pd.read_csv(OUTPUT_TABLES / "innings_survival_dataset.csv")

    observed_boundary_waits = innings_df.loc[
        innings_df.first_boundary_event == 1, "first_boundary_attempt"
    ].dropna().values
    observed_wicket_waits = innings_df.loc[
        innings_df.first_wicket_event == 1, "first_wicket_attempt"
    ].dropna().values

    print("=" * 70)
    print("PARAMETRIC BOOTSTRAP CALIBRATION OF THE CHI-SQUARE GOF TEST")
    print("=" * 70)
    print(f"n_simulations = {args.n_simulations}, seed = {args.seed}")

    boundary_result = calibrate(
        observed_boundary_waits, "BOUNDARIES (primary result -- Comment 8/9)",
        args.n_simulations, args.seed
    )
    wicket_result = calibrate(
        observed_wicket_waits, "WICKETS (included for completeness only)",
        args.n_simulations, args.seed
    )

    pd.DataFrame([boundary_result]).to_csv(
        OUTPUT_TABLES / "parametric_bootstrap_gof_boundary.csv", index=False
    )
    pd.DataFrame([wicket_result]).to_csv(
        OUTPUT_TABLES / "parametric_bootstrap_gof_wicket.csv", index=False
    )

    print("\n" + "=" * 70)
    print("INTERPRETATION")
    print("=" * 70)
    p = boundary_result["bootstrap_empirical_p"]
    if p < 0.05:
        print(f"Boundary bootstrap p = {p:.4f} < 0.05 -> the departure from the geometric")
        print("model is significant at the 5% level on the calibrated test (retain the")
        print("significance claim per Comment 9).")
    else:
        print(f"Boundary bootstrap p = {p:.4f} >= 0.05 -> describe as a suggestive")
        print("departure rather than a statistically significant rejection (per Comment 9).")

    print(f"\nSaved: {OUTPUT_TABLES / 'parametric_bootstrap_gof_boundary.csv'}")
    print(f"Saved: {OUTPUT_TABLES / 'parametric_bootstrap_gof_wicket.csv'}")


if __name__ == "__main__":
    main()