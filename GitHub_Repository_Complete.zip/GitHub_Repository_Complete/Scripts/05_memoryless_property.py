import numpy as np
import pandas as pd
from lifelines import KaplanMeierFitter
from scipy.stats import chisquare, chi2
from common import OUTPUT_TABLES

def fit_geometric_mle(observed_waits):
    """MLE of the geometric parameter p, fit directly to the observed
    (uncensored) waiting times. p_mle = 1 / mean(waiting time)."""
    observed_waits = np.asarray(observed_waits, dtype=float)
    return 1.0 / observed_waits.mean()


def get_observed_counts(innings_data, event_type):
    """Extract observed wait time counts for chi-square test"""
    if event_type == 'boundary':
        observed_waits = innings_data[innings_data['first_boundary_event'] == 1]['first_boundary_attempt'].dropna().values
    else:
        observed_waits = innings_data[innings_data['first_wicket_event'] == 1]['first_wicket_attempt'].dropna().values
    return observed_waits


def conditional_survival(kmf, m, n):
    # Use .values[0] as in the notebook
    S_m = kmf.survival_function_at_times(m).values[0]
    S_mn = kmf.survival_function_at_times(m + n).values[0]
    return np.nan if S_m <= 0 else S_mn / S_m


def run_test(innings_df, duration_col, event_col, event_name, ms, ns):
    kmf = KaplanMeierFitter()
    kmf.fit(innings_df[duration_col], innings_df[event_col], label=event_name)
    rows = []
    for m in ms:
        for n in ns:
            conditional = conditional_survival(kmf, m, n)
            # Use .values[0] for unconditional survival
            unconditional = float(kmf.survival_function_at_times(n).values[0])
            rows.append({
                "event": event_name,
                "m": m,
                "n": n,
                "conditional_survival_S_m+n_over_S_m": conditional,
                "unconditional_survival_S_n": unconditional,
                "difference": conditional - unconditional
            })
    return pd.DataFrame(rows)


def run_chi_square_test(observed_waits, p_hat, event_name):
    n = len(observed_waits)
    max_ball = max(observed_waits)
    
    # Dynamically find a cutoff where expected count drops below 5
    cutoff = 1
    while cutoff <= max_ball:
        expected_count = n * ((1 - p_hat)**(cutoff - 1) * p_hat)
        if expected_count < 5:
            break
        cutoff += 1
    
    # Ensure we have at least a few bins; force cutoff to at least 4
    cutoff = max(4, cutoff)
    
    # Create bins: 1, 2, ..., cutoff-1, cutoff+
    bins = list(range(1, cutoff)) + [cutoff]
    observed_counts = []
    
    for i in range(len(bins) - 1):
        count = sum((observed_waits >= bins[i]) & (observed_waits < bins[i+1]))
        observed_counts.append(count)
    # Last bin: >= cutoff
    count = sum(observed_waits >= bins[-1])
    observed_counts.append(count)
    
    # Expected counts under Geometric distribution
    expected_counts = []
    for i in range(len(bins) - 1):
        if bins[i] == 1:
            prob = (1 - (1 - p_hat)**(bins[i+1] - 1))
        else:
            prob = ((1 - p_hat)**(bins[i] - 1) - (1 - p_hat)**(bins[i+1] - 1))
        expected_counts.append(n * prob)
    # Last bin: P(X >= cutoff)
    prob = (1 - p_hat)**(cutoff - 1)
    expected_counts.append(n * prob)
    
    # Calculate Chi-Square statistic
    chi2_stat = np.sum((np.array(observed_counts) - np.array(expected_counts))**2 / np.array(expected_counts))
    # Degrees of freedom: bins - 1 - 1 (estimated parameter p)
    df = len(bins) - 2

    # Lower-bound p-value: reference distribution chi2(df) (the value used previously)
    p_val = 1 - chi2.cdf(chi2_stat, df)

    # === NEW: upper-bound p-value under chi2(df + 1) (Chernoff & Lehmann, 1954) ===
    p_val_upper = 1 - chi2.cdf(chi2_stat, df + 1)

    print(f"\n{event_name}:")
    print(f"  - Number of innings: {n}")
    print(f"  - Chi-Square Statistic: {chi2_stat:.4f}")
    print(f"  - Degrees of Freedom: {df}")
    print(f"  - p-value (chi2(df), lower bound): {p_val:.4f}")
    print(f"  - p-value (chi2(df+1), Chernoff-Lehmann upper bound): {p_val_upper:.4f}")
    print(f"  - Honest p-value range: [{p_val:.4f}, {p_val_upper:.4f}]")
    print(f"  - Rate used: {p_hat:.6f}")

    # Return both bounds instead of a single number
    return p_val, p_val_upper, chi2_stat, df


def main():
    # Load the data
    innings_df = pd.read_csv(OUTPUT_TABLES / "innings_survival_dataset.csv")
    
    # ============================================
    # PART 1: MEMORYLESS PROPERTY DIAGNOSTIC
    # ============================================
    result = pd.concat([
        run_test(innings_df, "first_wicket_attempt", "first_wicket_event", "First wicket", [5,10,15], [5,10]),
        run_test(innings_df, "first_boundary_attempt", "first_boundary_event", "First boundary", [2,5,10], [2,5])
    ], ignore_index=True)
    result.to_csv(OUTPUT_TABLES / "memoryless_comparison.csv", index=False)
    
    print("=== MEMORYLESS-PROPERTY DIAGNOSTIC ===")
    print(result.to_string(index=False))
    print("\nFor a geometric process, S(m+n)/S(m) = S(n). This is a diagnostic, not a formal hypothesis test.")
    
    # ============================================
    # PART 2: FORMAL GOODNESS-OF-FIT TEST (DISCRETE)
    # ============================================
    print("\n" + "="*60)
    print("CHI-SQUARE GOODNESS-OF-FIT TEST (DISCRETE)")
    print("="*60)
    print("NOTE: KS test is NOT used here because wait-times are discrete.")
    print("      Chi-Square is the correct test for discrete distributions.")
    print("      p is fit by MLE to the waiting-time sample under test, not")
    print("      taken from an external per-ball rate -- this tests whether the")
    print("      SHAPE is geometric, not whether it matches an assumed rate.")
    print("      Caveat: because p is estimated from the ungrouped sample rather")
    print("      than from the grouped bin counts, the true null distribution of")
    print("      the statistic lies between chi2(df) and chi2(df+1) (Chernoff &")
    print("      Lehmann, 1954). We now report BOTH endpoints of that range as")
    print("      an explicit [lower, upper] p-value interval instead of a")
    print("      qualitative hedge.\n")
    
    # Extract observed wait times
    observed_boundary_waits = innings_df[innings_df['first_boundary_event'] == 1]['first_boundary_attempt'].dropna().values
    observed_wicket_waits = innings_df[innings_df['first_wicket_event'] == 1]['first_wicket_attempt'].dropna().values
    
    # === FIX: fit p via MLE to the waiting-time sample itself, not a per-ball rate ===
    BOUNDARY_RATE = fit_geometric_mle(observed_boundary_waits)
    WICKET_RATE = fit_geometric_mle(observed_wicket_waits)

    # For reference/reporting only -- NOT used in the test below. Kept so the
    # article can still show how far the naive per-ball rate sits from the
    # rate the waiting times actually imply.
    legal_df = pd.read_csv(OUTPUT_TABLES / "legal_deliveries_prepared.csv")
    naive_pooled_wicket_rate = legal_df['is_wicket'].sum() / len(legal_df)
    naive_pooled_boundary_rate = legal_df['is_boundary'].sum() / len(legal_df)

    print(f"Using BOUNDARY_RATE = {BOUNDARY_RATE:.6f} (MLE fit to the {len(observed_boundary_waits)} observed waiting times)")
    print(f"Using WICKET_RATE   = {WICKET_RATE:.6f} (MLE fit to the {len(observed_wicket_waits)} observed waiting times)")
    print(f"  [for reference] naive pooled per-ball boundary rate = {naive_pooled_boundary_rate:.6f}")
    print(f"  [for reference] naive pooled per-ball wicket rate   = {naive_pooled_wicket_rate:.6f}\n")
    
    # Run the correct discrete test, against the correctly-fit parameter.
    # Now unpacks (p_lower, p_upper, chi2_stat, df) instead of a single p-value.
    p_boundary_lower, p_boundary_upper, chi2_boundary, df_boundary = run_chi_square_test(
        observed_boundary_waits, BOUNDARY_RATE, "BOUNDARIES"
    )
    p_wicket_lower, p_wicket_upper, chi2_wicket, df_wicket = run_chi_square_test(
        observed_wicket_waits, WICKET_RATE, "WICKETS"
    )

    # === NEW: save the chi-square + p-value-range results to a table so the
    # article can cite exact numbers instead of re-deriving them by hand.
    chi_square_results = pd.DataFrame([
        {
            "event": "First boundary",
            "chi2_stat": chi2_boundary,
            "df": df_boundary,
            "p_value_lower_chi2_df": p_boundary_lower,
            "p_value_upper_chi2_df_plus_1": p_boundary_upper,
            "rate_used_p_mle": BOUNDARY_RATE,
        },
        {
            "event": "First wicket",
            "chi2_stat": chi2_wicket,
            "df": df_wicket,
            "p_value_lower_chi2_df": p_wicket_lower,
            "p_value_upper_chi2_df_plus_1": p_wicket_upper,
            "rate_used_p_mle": WICKET_RATE,
        },
    ])
    chi_square_results.to_csv(OUTPUT_TABLES / "chi_square_gof_results_with_cl_bounds.csv", index=False)
    
    # ============================================
    # PART 3: INTERPRETATION
    # ============================================
    print("\n" + "="*60)
    print("INTERPRETATION")
    print("="*60)
    
    print("\nBOUNDARIES:")
    print(f"  Honest p-value range: [{p_boundary_lower:.4f}, {p_boundary_upper:.4f}]")
    if p_boundary_upper < 0.05:
        print("  * Even the conservative (upper-bound) p-value is < 0.05 -> departure from")
        print("    geometric is significant regardless of which endpoint of the range you use.")
    elif p_boundary_lower < 0.05 <= p_boundary_upper:
        print("  * The range straddles 0.05: the naive chi2(df) p-value (lower bound) suggests")
        print("    a significant departure, but the Chernoff-Lehmann upper bound does not.")
        print("    This result should be reported as SUGGESTIVE, not as a settled significant")
        print("    finding -- the true p-value could plausibly sit on either side of 0.05.")
    else:
        print("  - Both endpoints are >= 0.05 -> no significant deviation from geometric.")
    
    print("\nWICKETS:")
    print(f"  Honest p-value range: [{p_wicket_lower:.4f}, {p_wicket_upper:.4f}]")
    if p_wicket_upper < 0.05:
        print("  * Even the conservative (upper-bound) p-value is < 0.05 -> significant departure.")
    elif p_wicket_lower < 0.05 <= p_wicket_upper:
        print("  * The range straddles 0.05 -- treat as suggestive only.")
    else:
        print("  - Both endpoints are >= 0.05 -> no significant deviation from geometric.")
        print("  -> The memoryless property holds for wickets (at aggregate level).")
    
    print("\n" + "="*60)
    print("SUMMARY")
    print("="*60)
    print(f"BOUNDARIES: p in [{p_boundary_lower:.4f}, {p_boundary_upper:.4f}] "
          f"-> {'SUGGESTIVE, straddles 0.05' if p_boundary_lower < 0.05 <= p_boundary_upper else ('REJECTS' if p_boundary_upper < 0.05 else 'FAILS TO REJECT')} geometric model")
    print(f"WICKETS:    p in [{p_wicket_lower:.4f}, {p_wicket_upper:.4f}] "
          f"-> {'SUGGESTIVE, straddles 0.05' if p_wicket_lower < 0.05 <= p_wicket_upper else ('REJECTS' if p_wicket_upper < 0.05 else 'FAILS TO REJECT')} geometric model")
    print("\nNote: The lower bound uses chi2(df); the upper bound uses chi2(df+1), per")
    print("      Chernoff & Lehmann (1954). Report the range, not a single p-value, when")
    print("      the parameter was estimated from the same ungrouped data being tested.")


if __name__ == "__main__":
    main()