import numpy as np
import pandas as pd
from common import OUTPUT_TABLES, load_data, prepare_analysis_view

def main():
    df = load_data()
    legal = prepare_analysis_view(df)
    innings_df = pd.read_csv(OUTPUT_TABLES / "innings_survival_dataset.csv")

    n = len(legal)
    wicket_count = int(legal["is_wicket"].sum())
    boundary_count = int(legal["is_boundary"].sum())

    p_wicket = wicket_count / n
    p_boundary = boundary_count / n

    unc_w = innings_df.loc[innings_df.first_wicket_event.eq(1), "first_wicket_attempt"]
    unc_b = innings_df.loc[innings_df.first_boundary_event.eq(1), "first_boundary_attempt"]

    p_mle_wicket = 1 / unc_w.mean()
    p_mle_boundary = 1 / unc_b.mean()

    result = pd.DataFrame([
        {
            "event": "First wicket",
            "legal_deliveries": n,
            "event_count": wicket_count,
            "p_hat_naive_per_ball": p_wicket,
            "naive_theoretical_mean_1_over_p_hat": 1 / p_wicket,
            "uncensored_first_event_mean": unc_w.mean(),
            "p_mle_fit_to_waits": p_mle_wicket,
            "censored_innings": int(innings_df.first_wicket_event.eq(0).sum()),
        },
        {
            "event": "First boundary",
            "legal_deliveries": n,
            "event_count": boundary_count,
            "p_hat_naive_per_ball": p_boundary,
            "naive_theoretical_mean_1_over_p_hat": 1 / p_boundary,
            "uncensored_first_event_mean": unc_b.mean(),
            "p_mle_fit_to_waits": p_mle_boundary,
            "censored_innings": int(innings_df.first_boundary_event.eq(0).sum()),
        }
    ])
    result.to_csv(OUTPUT_TABLES / "geometric_baseline_summary.csv", index=False)

    print("=== GEOMETRIC BASELINE ===")
    print(result.to_string(index=False))
    print("\nNOTE: p_hat_naive_per_ball is for the introductory 'does this look like a")
    print("coin flip' comparison only. p_mle_fit_to_waits is the parameter that must")
    print("be passed into the formal chi-square goodness-of-fit test in script 05.")

if __name__ == "__main__":
    main()