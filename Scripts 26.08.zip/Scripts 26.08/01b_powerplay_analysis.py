#!/usr/bin/env python
"""
Powerplay Boundary Rate Analysis

This script computes the boundary rate during T20 powerplay overs (overs 1-6)
and performs a goodness-of-fit test against the geometric distribution.

This was added to address the reviewer's comment that the 26.9%/p=0.0051
figure in the article was not reproducible from the existing scripts.

- Uses the SAME boundary definition as common.py: runs_off_bat == 4 or 6
- Uses T20 powerplay: overs 1-6 (over_no 0-5)
- This matches the article's stated definition and the rest of the pipeline
- Outputs: T20 powerplay rate (should be ~26.8%)

Usage:
    python 01b_powerplay_analysis.py
    python 01b_powerplay_analysis.py --output powerplay_results.csv
"""

import argparse
import numpy as np
import pandas as pd
from scipy.stats import chi2
from pathlib import Path
import sys
import warnings

warnings.filterwarnings('ignore')

# Import from common
try:
    from common import OUTPUT_TABLES, load_data, prepare_analysis_view
except ImportError:
    # If common.py is in a parent directory, try adding it to path
    import os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    try:
        from common import OUTPUT_TABLES, load_data, prepare_analysis_view
    except ImportError:
        # Final fallback
        OUTPUT_TABLES = Path("tables")
        print(f"Warning: Could not import from common. Using fallback paths: {OUTPUT_TABLES}")
        
        def load_data():
            """Fallback load_data function"""
            data_path = Path("data") / "data-ball_by_ball.csv"
            if not data_path.exists():
                data_path = Path("..") / "data" / "data-ball_by_ball.csv"
            if not data_path.exists():
                raise FileNotFoundError(f"Data file not found: {data_path}")
            df = pd.read_csv(data_path)
            return df
        
        def prepare_analysis_view(df):
            """Fallback prepare_analysis_view function"""
            legal = df.loc[df["is_legal_delivery"]].copy()
            legal["is_wicket"] = legal["wicket_flag"]
            legal["is_boundary"] = legal["runs_off_bat"].isin([4, 6])
            legal = legal.sort_values(
                ["match_id", "innings_no", "over_no", "ball_no"],
                kind="mergesort"
            ).reset_index(drop=True)
            return legal

OUTPUT_TABLES.mkdir(parents=True, exist_ok=True)


def load_powerplay_data():
    """
    Load and filter data to T20 powerplay overs (overs 1-6).
    
    IMPORTANT: In T20 cricket, the powerplay is the first 6 overs.
    In 0-indexed data: over_no 0-5 corresponds to overs 1-6.
    
    Uses the corrected boundary definition (exactly 4 or 6 runs).
    """
    print("\n" + "="*70)
    print("T20 POWERPLAY BOUNDARY RATE ANALYSIS")
    print("="*70)
    print("Powerplay: Overs 1-6 (over_no 0-5 in 0-indexed data)")
    print("Boundary definition: Exactly 4 or 6 runs off the bat")
    print("="*70)
    
    # Load data using common.py functions
    df = load_data()
    legal = prepare_analysis_view(df)
    
    print(f"\n[Data Summary]")
    print(f"  Total legal deliveries: {len(legal):,}")
    
    # Filter to T20 powerplay overs (1-6, which are over_no 0-5 in 0-indexed data)
    powerplay = legal[legal['over_no'] < 6].copy()
    
    print(f"  Powerplay deliveries (overs 1-6): {len(powerplay):,}")
    print(f"  Powerplay boundaries (exactly 4 or 6 runs): {powerplay['is_boundary'].sum():,}")
    
    return powerplay


def compute_powerplay_rate(powerplay_df):
    """
    Compute the boundary rate during T20 powerplay overs.
    """
    n_deliveries = len(powerplay_df)
    n_boundaries = powerplay_df['is_boundary'].sum()
    rate = n_boundaries / n_deliveries
    
    print(f"\n[T20 Powerplay Boundary Rate]")
    print(f"  Boundaries: {n_boundaries:,} / {n_deliveries:,} deliveries")
    print(f"  Rate: {rate:.4f} ({rate*100:.2f}%)")
    
    return rate, n_boundaries, n_deliveries


def get_observed_first_boundary_waits(powerplay_df):
    """
    Get the waiting time (ball number) for the first boundary in each innings
    within the T20 powerplay overs.
    """
    # Group by match and innings to find first boundary
    powerplay_sorted = powerplay_df.sort_values(['match_id', 'innings_no', 'over_no', 'ball_no'])
    
    # Mark the first boundary in each innings
    first_boundary_mask = (
        powerplay_sorted.groupby(['match_id', 'innings_no'])['is_boundary']
        .transform(lambda x: (x == 1) & (~x.duplicated()))
    )
    
    # Get innings where a boundary occurred
    first_boundary_innings = powerplay_sorted[first_boundary_mask].copy()
    
    # Calculate ball position (1-indexed) within the innings
    first_boundary_innings['ball_position'] = (
        first_boundary_innings.groupby(['match_id', 'innings_no']).cumcount() + 1
    )
    
    waits = first_boundary_innings['ball_position'].values
    
    print(f"\n[First Boundary Waiting Times in Powerplay]")
    print(f"  Innings with a boundary in powerplay: {len(waits):,}")
    if len(waits) > 0:
        print(f"  Mean wait: {np.mean(waits):.2f} balls")
        print(f"  Median wait: {np.median(waits):.2f} balls")
    
    return waits


def run_goodness_of_fit(observed_waits, p_boundary):
    """
    Run chi-square goodness-of-fit test comparing observed waits to geometric.
    """
    n = len(observed_waits)
    if n == 0:
        print("\n[ERROR] No observed waits to test!")
        return {
            'chi2': np.nan,
            'p_value': np.nan,
            'df': 0,
            'cutoff': 0,
            'n_observations': 0,
            'observed_counts': [],
            'expected_counts': [],
            'bins': []
        }
    
    max_ball = max(observed_waits)
    
    # Determine bins with expected count >= 5
    cutoff = 1
    while cutoff <= max_ball:
        expected_count = n * ((1 - p_boundary) ** (cutoff - 1) * p_boundary)
        if expected_count < 5:
            break
        cutoff += 1
    cutoff = max(4, cutoff)
    
    # Create bins
    bins = list(range(1, cutoff)) + [cutoff]
    
    # Observed counts
    observed_counts = []
    for i in range(len(bins) - 1):
        count = sum((observed_waits >= bins[i]) & (observed_waits < bins[i+1]))
        observed_counts.append(count)
    count = sum(observed_waits >= bins[-1])
    observed_counts.append(count)
    
    # Expected counts under geometric
    expected_counts = []
    for i in range(len(bins) - 1):
        if bins[i] == 1:
            prob = (1 - (1 - p_boundary) ** (bins[i+1] - 1))
        else:
            prob = ((1 - p_boundary) ** (bins[i] - 1) - (1 - p_boundary) ** (bins[i+1] - 1))
        expected_counts.append(n * prob)
    prob = (1 - p_boundary) ** (cutoff - 1)
    expected_counts.append(n * prob)
    
    # Chi-square statistic
    chi2_stat = np.sum((np.array(observed_counts) - np.array(expected_counts))**2 / np.array(expected_counts))
    df = len(bins) - 2
    p_value = 1 - chi2.cdf(chi2_stat, df)
    
    print(f"\n[Goodness-of-Fit Test]")
    print(f"  Number of observations: {n:,}")
    print(f"  Bins used: {len(bins)} categories, df = {df}")
    print(f"  Chi-square: {chi2_stat:.4f}")
    print(f"  P-value: {p_value:.4f}")
    print(f"  Geometric pattern: {'YES (p > 0.05)' if p_value > 0.05 else 'NO (p < 0.05)'}")
    
    return {
        'chi2': chi2_stat,
        'p_value': p_value,
        'df': df,
        'cutoff': cutoff,
        'n_observations': n,
        'observed_counts': observed_counts,
        'expected_counts': expected_counts,
        'bins': bins
    }


def main():
    parser = argparse.ArgumentParser(
        description="Compute T20 powerplay boundary rate and GOF test"
    )
    parser.add_argument(
        "--output",
        type=str,
        default="powerplay_analysis_results.csv",
        help="Output filename for results CSV"
    )
    args = parser.parse_args()
    
    # Load powerplay data
    powerplay_df = load_powerplay_data()
    
    # Compute rate
    rate, n_boundaries, n_deliveries = compute_powerplay_rate(powerplay_df)
    
    # Get first boundary waiting times
    waits = get_observed_first_boundary_waits(powerplay_df)
    
    # Run goodness-of-fit test
    gof_results = run_goodness_of_fit(waits, rate)
    
    # Summary
    print("\n" + "="*70)
    print("SUMMARY FOR ARTICLE")
    print("="*70)
    print(f"T20 Powerplay (overs 1-6) boundary rate: {rate*100:.2f}%")
    if not np.isnan(gof_results['p_value']):
        print(f"Goodness-of-fit p-value: {gof_results['p_value']:.4f}")
    else:
        print("Goodness-of-fit: Insufficient data")
    print("\n[IMPORTANT]")
    print("  This uses the CORRECTED boundary definition (exactly 4 or 6 runs)")
    print("  This uses T20 powerplay: overs 1-6 (over_no 0-5)")
    print("="*70)
    
    # Save results
    results = {
        'analysis': 'T20 Powerplay Boundary Rate',
        'boundary_definition': 'exactly 4 or 6 runs',
        'powerplay_overs': '1-6 (T20)',
        'n_deliveries': n_deliveries,
        'n_boundaries': n_boundaries,
        'rate': rate,
        'rate_percent': rate * 100,
        'chi2': gof_results['chi2'],
        'p_value': gof_results['p_value'],
        'df': gof_results['df'],
        'n_observations': gof_results['n_observations'],
        'note': 'T20 powerplay (overs 1-6) - matches article definition'
    }
    
    results_df = pd.DataFrame([results])
    output_path = OUTPUT_TABLES / args.output
    results_df.to_csv(output_path, index=False)
    print(f"\n[OK] Results saved to: {output_path}")
    
    # Also save a clean summary for the article
    summary_lines = [
        "T20 POWERPLAY BOUNDARY RATE ANALYSIS",
        "="*50,
        f"Powerplay: Overs 1-6 (T20 cricket)",
        f"Boundary definition: exactly 4 or 6 runs (corrected)",
        f"Powerplay deliveries (overs 1-6): {n_deliveries:,}",
        f"Powerplay boundaries: {n_boundaries:,}",
        f"Powerplay boundary rate: {rate*100:.2f}%",
        f"Goodness-of-fit p-value: {gof_results['p_value']:.4f}",
        "",
        "NOTE: This is T20 powerplay (overs 1-6)"
    ]
    
    summary_path = OUTPUT_TABLES / "powerplay_analysis_summary.txt"
    with open(summary_path, 'w') as f:
        f.write('\n'.join(summary_lines))
    print(f"[OK] Summary saved to: {summary_path}")


if __name__ == "__main__":
    main()