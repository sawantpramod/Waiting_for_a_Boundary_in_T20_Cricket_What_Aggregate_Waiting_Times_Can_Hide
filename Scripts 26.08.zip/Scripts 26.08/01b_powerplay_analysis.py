#!/usr/bin/env python
"""
Powerplay Boundary Rate Analysis

This script computes the boundary rate during T20 powerplay overs (overs 1-6).

This was added to address the reviewer's comment that the 26.9%/p=0.0051
figure in the article was not reproducible from the existing scripts.

- Uses the SAME boundary definition as common.py: runs_off_bat == 4 or 6
- Uses T20 powerplay: overs 1-6 (over_no 0-5)
- This matches the article's stated definition and the rest of the pipeline
- Outputs: T20 powerplay rate (should be ~26.8%)

Usage:
    python 01b_powerplay_analysis.py
"""

import argparse
import numpy as np
import pandas as pd
from pathlib import Path
import sys
import warnings

warnings.filterwarnings('ignore')

# Import from common
try:
    from common import OUTPUT_TABLES, load_data, prepare_analysis_view
except ImportError:
    # If common.py is in a parent directory, try adding it to path
    import os
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    try:
        from common import OUTPUT_TABLES, load_data, prepare_analysis_view
    except ImportError:
        # Final fallback
        OUTPUT_TABLES = Path("tables")
        print(f"Warning: Could not import from common. Using fallback paths: {OUTPUT_TABLES}")
        
        def load_data():
            """Fallback load_data function"""
            data_path = Path("data") / "data-ball_by_ball.csv"
            if not data_path.exists():
                data_path = Path("..") / "data" / "data-ball_by_ball.csv"
            if not data_path.exists():
                raise FileNotFoundError(f"Data file not found: {data_path}")
            df = pd.read_csv(data_path)
            return df
        
        def prepare_analysis_view(df):
            """Fallback prepare_analysis_view function"""
            legal = df.loc[df["is_legal_delivery"]].copy()
            legal["is_wicket"] = legal["wicket_flag"]
            legal["is_boundary"] = legal["runs_off_bat"].isin([4, 6])
            legal = legal.sort_values(
                ["match_id", "innings_no", "over_no", "ball_no"],
                kind="mergesort"
            ).reset_index(drop=True)
            return legal

OUTPUT_TABLES.mkdir(parents=True, exist_ok=True)


def load_powerplay_data():
    """
    Load and filter data to T20 powerplay overs (overs 1-6).
    
    IMPORTANT: In T20 cricket, the powerplay is the first 6 overs.
    In 0-indexed data: over_no 0-5 corresponds to overs 1-6.
    
    Uses the corrected boundary definition (exactly 4 or 6 runs).
    """
    print("\n" + "="*70)
    print("T20 POWERPLAY BOUNDARY RATE ANALYSIS")
    print("="*70)
    print("Powerplay: Overs 1-6 (over_no 0-5 in 0-indexed data)")
    print("Boundary definition: Exactly 4 or 6 runs off the bat")
    print("="*70)
    
    # Load data using common.py functions
    df = load_data()
    legal = prepare_analysis_view(df)
    
    print(f"\n[Data Summary]")
    print(f"  Total legal deliveries: {len(legal):,}")
    
    # Filter to T20 powerplay overs (1-6, which are over_no 0-5 in 0-indexed data)
    powerplay = legal[legal['over_no'] < 6].copy()
    
    print(f"  Powerplay deliveries (overs 1-6): {len(powerplay):,}")
    print(f"  Powerplay boundaries (exactly 4 or 6 runs): {powerplay['is_boundary'].sum():,}")
    
    return powerplay


def compute_powerplay_rate(powerplay_df):
    """
    Compute the boundary rate during T20 powerplay overs.
    """
    n_deliveries = len(powerplay_df)
    n_boundaries = powerplay_df['is_boundary'].sum()
    rate = n_boundaries / n_deliveries
    
    print(f"\n[T20 Powerplay Boundary Rate]")
    print(f"  Boundaries: {n_boundaries:,} / {n_deliveries:,} deliveries")
    print(f"  Rate: {rate:.4f} ({rate*100:.2f}%)")
    
    return rate, n_boundaries, n_deliveries


def main():
    parser = argparse.ArgumentParser(
        description="Compute T20 powerplay boundary rate"
    )
    args = parser.parse_args()
    
    # Load powerplay data
    powerplay_df = load_powerplay_data()
    
    # Compute rate
    rate, n_boundaries, n_deliveries = compute_powerplay_rate(powerplay_df)
    
    # Summary
    print("\n" + "="*70)
    print("SUMMARY FOR ARTICLE")
    print("="*70)
    print(f"T20 Powerplay (overs 1-6) boundary rate: {rate*100:.2f}%")
    print("\n[IMPORTANT]")
    print("  This uses the CORRECTED boundary definition (exactly 4 or 6 runs)")
    print("  This uses T20 powerplay: overs 1-6 (over_no 0-5)")
    print("="*70)
    
    # Save results
    results = {
        'analysis': 'T20 Powerplay Boundary Rate',
        'boundary_definition': 'exactly 4 or 6 runs',
        'powerplay_overs': '1-6 (T20)',
        'n_deliveries': n_deliveries,
        'n_boundaries': n_boundaries,
        'rate': rate,
        'rate_percent': rate * 100,
        'note': 'T20 powerplay (overs 1-6) - matches article definition'
    }
    
    results_df = pd.DataFrame([results])
    output_path = OUTPUT_TABLES / "powerplay_analysis_results.csv"
    results_df.to_csv(output_path, index=False)
    print(f"\n[OK] Results saved to: {output_path}")
    
    # Save a clean summary for the article
    summary_lines = [
        "T20 POWERPLAY BOUNDARY RATE ANALYSIS",
        "="*50,
        f"Powerplay: Overs 1-6 (T20 cricket)",
        f"Boundary definition: exactly 4 or 6 runs (corrected)",
        f"Powerplay deliveries (overs 1-6): {n_deliveries:,}",
        f"Powerplay boundaries: {n_boundaries:,}",
        f"Powerplay boundary rate: {rate*100:.2f}%",
        "",
        "NOTE: This is T20 powerplay (overs 1-6) - descriptive statistics only"
    ]
    
    summary_path = OUTPUT_TABLES / "powerplay_analysis_summary.txt"
    with open(summary_path, 'w') as f:
        f.write('\n'.join(summary_lines))
    print(f"[OK] Summary saved to: {summary_path}")


if __name__ == "__main__":
    main()