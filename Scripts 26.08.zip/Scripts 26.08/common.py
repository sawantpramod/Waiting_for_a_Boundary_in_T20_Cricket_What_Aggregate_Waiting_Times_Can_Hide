from pathlib import Path
import hashlib
import pandas as pd
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
DATA_FILE = ROOT / "data" / "data-ball_by_ball.csv"
OUTPUT_TABLES = ROOT / "outputs" / "tables"
OUTPUT_FIGURES = ROOT / "outputs" / "figures"
LOG_FILE = ROOT / "logs" / "run_log.txt"

REQUIRED_COLUMNS = [
    "match_id", "innings_no", "over_no", "ball_no",
    "runs_off_bat", "wicket_flag", "is_legal_delivery",
    "batting_team", "overs_category"
]

def ensure_dirs():
    OUTPUT_TABLES.mkdir(parents=True, exist_ok=True)
    OUTPUT_FIGURES.mkdir(parents=True, exist_ok=True)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)

def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def _to_bool(series, name):
    # Robust conversion: unlike astype(bool), the string "FALSE" does not become True.
    if pd.api.types.is_bool_dtype(series):
        return series.copy()
    mapping = {
        "true": True, "false": False,
        "1": True, "0": False,
        "yes": True, "no": False,
        "y": True, "n": False
    }
    s = series.astype("string").str.strip().str.lower()
    bad = s.notna() & ~s.isin(mapping)
    if bad.any():
        raise ValueError(f"{name} contains unrecognised boolean values: {series[bad].unique()[:10]}")
    return s.map(mapping).astype("boolean").fillna(False).astype(bool)

def load_data():
    ensure_dirs()
    if not DATA_FILE.exists():
        raise FileNotFoundError(f"Data file not found: {DATA_FILE}")
    df = pd.read_csv(DATA_FILE)
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    df["is_legal_delivery"] = _to_bool(df["is_legal_delivery"], "is_legal_delivery")
    df["wicket_flag"] = _to_bool(df["wicket_flag"], "wicket_flag")
    return df

def prepare_analysis_view(df):
    """
    Creates a DERIVED legal-delivery view.
    The original df is never modified, filtered in-place, or overwritten.
    """
    legal = df.loc[df["is_legal_delivery"]].copy()
    legal["is_wicket"] = legal["wicket_flag"]
    # FIXED: a boundary is runs off the bat of EXACTLY 4 or 6, not >= 4.
    # The previous `>= 4` definition also counted legal deliveries where a
    # batter ran 5 (a rare all-run five, or 4 + an overthrow scored off the
    # bat) as boundaries. In this dataset that inflated the boundary count
    # from 3,740 to 3,746 -- a small effect (6 of 16,639 legal deliveries),
    # but it silently disagreed with the article's own stated definition
    # ("boundary means runs off the bat are exactly 4 or 6") and with every
    # boundary count reported in the article. Re-run the full pipeline
    # (01 through 10) after this fix so every downstream table is
    # consistent with a single, correct definition.
    legal["is_boundary"] = legal["runs_off_bat"].isin([4, 6])
    legal = legal.sort_values(
        ["match_id", "innings_no", "over_no", "ball_no"],
        kind="mergesort"
    ).reset_index(drop=True)
    return legal

def log(message):
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(message.rstrip() + "\n")