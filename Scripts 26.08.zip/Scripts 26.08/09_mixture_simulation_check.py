#!/usr/bin/env python
"""
Mixture Simulation Check: Can Innings-Level Heterogeneity Reproduce the
Observed Gap Pattern?

This script directly tests the heterogeneity/frailty hypothesis raised in the
"A Working Hypothesis" section by SIMULATING data under that hypothesis and
checking whether the simulation reproduces the observed conditional-minus-
unconditional survival gaps.

CORRECTED VERSION 2:
- FIXED: Reads exact tercile rates and sizes dynamically from the output of
  09_stratification_analysis.py instead of using hardcoded values. This
  resolves the reviewer's discrepancy where Script 10 used 0.242 while
  Script 09 correctly used 0.2513. 

Usage:
    python 10_mixture_simulation_check.py
    python 10_mixture_simulation_check.py --n-simulations 20000
"""

import argparse
import numpy as np
import pandas as pd
from pathlib import Path
import sys
import warnings

warnings.filterwarnings("ignore")

try:
    from common import OUTPUT_TABLES, OUTPUT_FIGURES
except ImportError:
    OUTPUT_TABLES = Path("tables")
    OUTPUT_FIGURES = Path("figures")
    print(f"Warning: Using fallback output paths: {OUTPUT_TABLES}")

OUTPUT_TABLES.mkdir(parents=True, exist_ok=True)
OUTPUT_FIGURES.mkdir(parents=True, exist_ok=True)

CHECKPOINTS = [(2, 2), (2, 5), (5, 2), (5, 5), (10, 2), (10, 5)]


def load_tercile_params():
    """
    Loads the exact MLE fitted rates and group sizes from the output
    of 09_stratification_analysis.py. This eliminates hardcoding errors.
    """
    filepath = OUTPUT_TABLES / "stratification_boundary_results.csv"
    if not filepath.exists():
        print(f"[ERROR] Could not find {filepath}.")
        print("Please run 09_stratification_analysis.py before 10_mixture_simulation_check.py")
        sys.exit(1)

    df = pd.read_csv(filepath)
    # Sort by boundary_rate to ensure we get Low, Middle, High order (ascending)
    df = df.sort_values('boundary_rate').reset_index(drop=True)

    rates = df['boundary_rate'].values
    sizes = df['n_innings'].values
    total_innings = int(sizes.sum())

    print("\n" + "-" * 70)
    print("RATES LOADED FROM SCRIPT 09 OUTPUT (VERIFIED)")
    print("-" * 70)
    print("Tercile rates and sizes (from 09_stratification_analysis.py):")
    for i, (rate, size) in enumerate(zip(rates, sizes)):
        print(f"  Group {i+1} -> rate = {rate:.4f}, n = {size}")
    print(f"  Total innings: {total_innings}")
    print("-" * 70 + "\n")

    return rates, sizes


def simulate_one_league(rng, terci_le_rates, terci_le_sizes):
    """
    Simulate one synthetic 'league' of TOTAL_INNINGS innings under the
    heterogeneity hypothesis.
    """
    group_ids = np.repeat(np.arange(len(terci_le_rates)), terci_le_sizes)
    rng.shuffle(group_ids)
    rates = terci_le_rates[group_ids]
    # np.random.Generator.geometric returns support {1, 2, 3, ...}
    waits = rng.geometric(rates)
    return waits


def empirical_survival(waits, t):
    """P(wait > t) computed directly from the simulated sample."""
    return np.mean(waits > t)


def gaps_for_one_league(waits):
    """Compute the conditional-minus-unconditional survival gap table."""
    rows = []
    for m, n in CHECKPOINTS:
        S_m = empirical_survival(waits, m)
        S_mn = empirical_survival(waits, m + n)
        S_n = empirical_survival(waits, n)
        conditional = np.nan if S_m <= 0 else S_mn / S_m
        gap = np.nan if np.isnan(conditional) else conditional - S_n
        rows.append(gap)
    return rows


def run_simulation(n_simulations=10000, seed=42):
    rng = np.random.default_rng(seed)
    
    # Critical fix: load parameters before running
    terci_le_rates, terci_le_sizes = load_tercile_params()
    total_innings = int(terci_le_sizes.sum())

    all_gaps = np.full((n_simulations, len(CHECKPOINTS)), np.nan)

    print(f"Simulating {n_simulations:,} synthetic leagues of {total_innings} innings each.")
    print("Each league draws innings from the SAME tercile structure as the real data.")
    print("No within-innings time-varying hazard is added (pure mixture model).\n")

    for i in range(n_simulations):
        waits = simulate_one_league(rng, terci_le_rates, terci_le_sizes)
        all_gaps[i, :] = gaps_for_one_league(waits)

    return all_gaps


def summarize(all_gaps):
    rows = []
    for j, (m, n) in enumerate(CHECKPOINTS):
        col = all_gaps[:, j]
        col = col[~np.isnan(col)]
        rows.append({
            "m": m,
            "n": n,
            "mean_gap": col.mean(),
            "median_gap": np.median(col),
            "pct_negative": 100 * np.mean(col < 0),
            "ci_2.5": np.percentile(col, 2.5),
            "ci_97.5": np.percentile(col, 97.5),
            "n_valid_simulations": len(col),
        })
    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser(
        description="Simulate mixtures of constant-rate innings and check "
                     "whether they can reproduce the observed negative "
                     "early gaps (publisher comment 2)."
    )
    parser.add_argument("--n-simulations", type=int, default=10000,
                         help="Number of synthetic leagues to simulate (default: 10000)")
    parser.add_argument("--seed", type=int, default=42,
                         help="Random seed for reproducibility (default: 42)")
    args = parser.parse_args()

    print("=" * 70)
    print("MIXTURE SIMULATION CHECK")
    print("=" * 70)

    all_gaps = run_simulation(n_simulations=args.n_simulations, seed=args.seed)
    summary_df = summarize(all_gaps)

    out_path = OUTPUT_TABLES / "mixture_simulation_gap_summary.csv"
    summary_df.to_csv(out_path, index=False)

    print("-" * 70)
    print("SIMULATED GAP TABLE (mixture of constant-rate innings)")
    print("-" * 70)
    print(summary_df.to_string(index=False))

    # Observed real-data gaps (verified from Script 05)
    observed_gaps = {
        (2, 2): -0.093, (2, 5): -0.077,
        (5, 2): -0.174, (5, 5): -0.192,
        (10, 2): 0.099, (10, 5): 0.212,
    }
    summary_df["observed_gap"] = [observed_gaps[(m, n)] for m, n in CHECKPOINTS]
    summary_df["observed_within_mixture_95pct_range"] = (
        (summary_df["observed_gap"] >= summary_df["ci_2.5"]) &
        (summary_df["observed_gap"] <= summary_df["ci_97.5"])
    )
    summary_df.to_csv(out_path, index=False)

    print("\n" + "-" * 70)
    print("COMPARISON: OBSERVED (REAL) GAPS vs. SIMULATED MIXTURE RANGE")
    print("-" * 70)
    print(summary_df[["m", "n", "observed_gap", "mean_gap", "ci_2.5",
                       "ci_97.5", "observed_within_mixture_95pct_range"]]
          .to_string(index=False))

    n_early_outside = (~summary_df.loc[summary_df["m"].isin([2, 5]),
                                        "observed_within_mixture_95pct_range"]).sum()

    print("\n" + "=" * 70)
    print("INTERPRETATION")
    print("=" * 70)
    print("A mixture of constant-rate innings can only ever produce gaps that")
    print("are, in expectation, >= 0 (Proschan, 1963; a direct consequence of")
    print("Chebyshev's sum inequality applied to the mixture survival function).\n")

    print(f"Mean simulated gap at every (m, n) checkpoint: "
          f"{'all >= 0' if (summary_df['mean_gap'] >= 0).all() else 'NOT all >= 0 -- check simulation'}")
    print(f"Observed early (m=2, m=5) gaps falling outside the simulated ")
    print(f"mixture's 95% range: {n_early_outside} of "
          f"{summary_df['m'].isin([2, 5]).sum()}")

    if (summary_df["mean_gap"] >= 0).all():
        print("\n[CONFIRMS ANALYTIC PROOF] The simulation confirms that a simple")
        print("mixture of constant-rate innings -- even using the EXACT tercile")
        print("rates and sizes observed in the real data -- cannot reproduce")
        print("negative gaps. The observed negative gaps at m=2 and m=5 are")
        print("therefore not explained by simple innings-level rate heterogeneity.")
    else:
        print("\n[UNEXPECTED] Simulated mean gaps went negative at some")
        print("checkpoint -- re-check the simulation before using this result.")

    print("=" * 70)


if __name__ == "__main__":
    main()