import subprocess
import sys
from pathlib import Path

# Define paths
SRC = Path(__file__).parent  # This is the Scripts folder
ROOT = SRC.parent  # This is the Reproducible folder
OUTPUT = ROOT / "outputs" / "tables"

# List of scripts to run in order
scripts = [
    "01_validate_and_prepare.py",
    "02_build_innings.py",
    "03_geometric_baseline.py",
    "04_kaplan_meier.py",
    "05_memoryless_property.py",
    "06_phase_analysis.py",
    "07_bootstrap_m10_analysis.py",
    "08_stratification_analysis.py",
    "09_mixture_simulation_check.py"
]

print("=" * 80)
print("RUNNING ALL SCRIPTS IN SEQUENCE")
print("=" * 80)

for script in scripts:
    script_path = SRC / script
    print(f"\n{'=' * 80}")
    print(f"RUNNING {script}")
    print("=" * 80)
    
    try:
        # IMPORTANT FIX: Use cwd as a string, not a Path object
        # Also, use shell=True for Windows compatibility
        result = subprocess.run(
            [sys.executable, str(script_path)],
            cwd=str(SRC),  # Convert to string explicitly
            capture_output=True,
            text=True,
            shell=True  # Add this for Windows
        )
        
        # Print output
        if result.stdout:
            print(result.stdout)
        if result.stderr:
            print("STDERR:", result.stderr)
            
        if result.returncode != 0:
            print(f"ERROR: Script {script} failed with return code {result.returncode}")
            break
        else:
            print(f"SUCCESS: {script} completed.")
            
    except Exception as e:
        print(f"EXCEPTION: {script} failed: {e}")
        break

print("\n" + "=" * 80)
print("ALL SCRIPTS COMPLETED")
print("=" * 80)