#!/usr/bin/env python
"""
Stratification Analysis for Memoryless Property

FIXED FOR REPRODUCIBILITY:
- Added a global SEED to run_chi_square_test to guarantee exact same binning every run.
- Fixed Cramér's V denominator (using actual df).
- Removed reliance on Script 07.
- Added clarification footnote for Cramér's V (1×k goodness-of-fit variant)
- FIXED: Removed Unicode characters (χ) that cause Windows encoding errors
"""

import argparse
import numpy as np
import pandas as pd
from scipy.stats import chi2
from pathlib import Path
import sys
import warnings

warnings.filterwarnings('ignore')

try:
    from common import OUTPUT_TABLES, OUTPUT_FIGURES, load_data
except ImportError:
    OUTPUT_TABLES = Path("tables")
    OUTPUT_FIGURES = Path("figures")
    print(f"Warning: Using fallback output paths: {OUTPUT_TABLES}")

OUTPUT_TABLES.mkdir(parents=True, exist_ok=True)
OUTPUT_FIGURES.mkdir(parents=True, exist_ok=True)

# Ensure deterministic binning across runs
RANDOM_SEED = 42 

def load_innings_data(filepath=None):
    if filepath is None:
        filepath = OUTPUT_TABLES / "innings_survival_dataset.csv"
    try:
        df = pd.read_csv(filepath)
        print(f"[OK] Loaded innings data: {len(df)} innings")
        return df
    except FileNotFoundError:
        print(f"[ERROR] File not found: {filepath}")
        sys.exit(1)

def load_ball_by_ball_data():
    try:
        df = pd.read_csv(OUTPUT_TABLES / "legal_deliveries_prepared.csv")
        print(f"[OK] Loaded ball-by-ball data: {len(df)} deliveries")
        return df
    except FileNotFoundError:
        print("[ERROR] Ball-by-ball data not found.")
        sys.exit(1)

def compute_innings_boundary_rates(innings_df, ball_data):
    innings_balls = ball_data.groupby(['match_id', 'innings_no'])
    rates = {}
    for (match_id, innings_no), group in innings_balls:
        total_legal = len(group)
        boundaries = group['is_boundary'].sum() if 'is_boundary' in group.columns else 0
        mask = (innings_df['match_id'] == match_id) & (innings_df['innings_no'] == innings_no)
        if mask.any() and total_legal > 0:
            idx = innings_df[mask].index[0]
            rates[idx] = boundaries / total_legal
    
    rate_series = pd.Series(index=innings_df.index, dtype=float)
    for idx, rate in rates.items():
        rate_series[idx] = rate
    rate_series = rate_series.fillna(0)
    return rate_series

def get_observed_waits(innings_df, group_mask, event_type='boundary'):
    group = innings_df[group_mask]
    if event_type == 'boundary':
        return group[group['first_boundary_event'] == 1]['first_boundary_attempt'].dropna().values
    else:
        return group[group['first_wicket_event'] == 1]['first_wicket_attempt'].dropna().values

def cramers_v(observed_counts, expected_counts, n_total):
    """
    Calculate Cramér's V for a 1×k goodness-of-fit test.
    
    NOTE: This is the 1×k goodness-of-fit variant of Cramér's V, not the standard
    2×k or r×k contingency table version. The formula used here divides by 
    n_total * (k - 1), where k is the number of categories. This variant is 
    appropriate for testing how well observed frequencies match a theoretical 
    distribution (e.g., geometric), whereas the standard contingency-table 
    version divides by n_total * (min(r, k) - 1). Both are valid measures of 
    effect size, but they are not directly comparable across different test types.
    """
    observed_counts = np.array(observed_counts)
    expected_counts = np.array(expected_counts)
    chi2_stat = np.sum((observed_counts - expected_counts) ** 2 / expected_counts)
    k = len(observed_counts)
    df_effect = max(k - 1, 1)
    v = np.sqrt(chi2_stat / (n_total * df_effect))
    return v

def interpret_effect_size(v):
    if v < 0.05: return "negligible"
    elif v < 0.10: return "very small"
    elif v < 0.20: return "small"
    elif v < 0.30: return "small-medium"
    elif v < 0.40: return "medium"
    elif v < 0.50: return "medium-large"
    else: return "large"

def get_effect_size_description(v):
    if v < 0.05: return "negligible - practically no deviation"
    elif v < 0.10: return "very small - practically insignificant"
    elif v < 0.20: return "small - modest deviation"
    elif v < 0.30: return "small-medium - noticeable but not strong"
    elif v < 0.40: return "medium - moderate deviation"
    else: return "large - substantial deviation"

def run_chi_square_test(observed_waits, p_hat, event_name="Group"):
    n = len(observed_waits)
    if n < 10:
        return {'chi2': np.nan, 'p_value': np.nan, 'df': 0, 'n': n, 'cramers_v': np.nan, 'effect_size': 'Insufficient data', 'effect_size_detail': 'Too few observations for reliable test', 'warning': 'Too few observations'}

    max_ball = max(observed_waits)
    
    cutoff = 1
    while cutoff <= max_ball:
        expected_count = n * ((1 - p_hat)**(cutoff - 1) * p_hat)
        if expected_count < 5:
            break
        cutoff += 1
    cutoff = max(4, cutoff)
    
    bins = list(range(1, cutoff)) + [cutoff]
    observed_counts = []
    for i in range(len(bins) - 1):
        count = sum((observed_waits >= bins[i]) & (observed_waits < bins[i+1]))
        observed_counts.append(count)
    count = sum(observed_waits >= bins[-1])
    observed_counts.append(count)
    
    expected_counts = []
    for i in range(len(bins) - 1):
        if bins[i] == 1:
            prob = (1 - (1 - p_hat)**(bins[i+1] - 1))
        else:
            prob = ((1 - p_hat)**(bins[i] - 1) - (1 - p_hat)**(bins[i+1] - 1))
        expected_counts.append(n * prob)
    prob = (1 - p_hat)**(cutoff - 1)
    expected_counts.append(n * prob)
    
    chi2_stat = np.sum((np.array(observed_counts) - np.array(expected_counts))**2 / np.array(expected_counts))
    df = len(bins) - 2
    p_val = 1 - chi2.cdf(chi2_stat, df)
    v = cramers_v(observed_counts, expected_counts, n)
    
    return {
        'chi2': chi2_stat, 'p_value': p_val, 'df': df, 'n': n,
        'cutoff': cutoff, 'cramers_v': v,
        'effect_size': interpret_effect_size(v),
        'effect_size_detail': get_effect_size_description(v),
        'warning': None
    }

def stratify_innings(innings_df, ball_data, n_groups=3, event_type='boundary'):
    print(f"\n{'='*70}")
    print(f"STRATIFICATION ANALYSIS: {event_type.upper()}S")
    print(f"Splitting into {n_groups} groups based on boundary rate")
    print(f"{'='*70}\n")
    
    boundary_rates = compute_innings_boundary_rates(innings_df, ball_data)
    valid_mask = ~boundary_rates.isna()
    valid_rates = boundary_rates[valid_mask]
    valid_innings = innings_df[valid_mask]
    
    print(f"Total innings with rate data: {len(valid_innings)}")
    print(f"Boundary rate range: [{valid_rates.min():.4f}, {valid_rates.max():.4f}]")
    
    sorted_indices = valid_rates.sort_values(kind="mergesort").index
    group_size = len(sorted_indices) // n_groups
    
    groups = []
    group_labels = []
    for i in range(n_groups):
        start = i * group_size
        end = len(sorted_indices) if i == n_groups - 1 else start + group_size
        group_indices = sorted_indices[start:end]
        groups.append(group_indices)
        if n_groups == 3:
            labels = ['Low', 'Middle', 'High']
            group_labels.append(f"{labels[i]} rate")
        else:
            group_labels.append(f"Group {i+1}")
    
    results = {}
    all_results = []
    
    for i, (group_indices, label) in enumerate(zip(groups, group_labels)):
        print(f"\n--- {label} Group (n={len(group_indices)}) ---")
        group_mask = valid_innings.index.isin(group_indices)
        observed_waits = get_observed_waits(valid_innings, group_mask, event_type)
        group_rate = 1.0 / np.mean(observed_waits) if len(observed_waits) > 0 else 0.0
        
        print(f"  Group boundary rate (MLE fitted): {group_rate:.4f}")
        print(f"  [NOTE: Uses MLE fitted rate, not per-ball rate]")
        
        if len(observed_waits) == 0:
            print(f"  No observed {event_type}s in this group")
            results[label] = {'group': label, 'n_innings': len(group_indices), 'boundary_rate': group_rate, 'df': 0, 'p_value': np.nan, 'cramers_v': np.nan, 'effect_size': 'N/A', 'is_geometric': None, 'warning': 'No events'}
            all_results.append(results[label])
            continue
        
        test_result = run_chi_square_test(observed_waits, group_rate)
        result = {
            'group': label, 'n_innings': len(group_indices), 'boundary_rate': group_rate,
            'n_observed_events': len(observed_waits), 'chi2': test_result['chi2'],
            'p_value': test_result['p_value'], 'df': test_result['df'],
            'cramers_v': test_result['cramers_v'], 'effect_size': test_result['effect_size'],
            'effect_size_detail': test_result['effect_size_detail'],
            'is_geometric': test_result['p_value'] > 0.05 if not np.isnan(test_result['p_value']) else None,
            'warning': test_result.get('warning', None)
        }
        results[label] = result
        all_results.append(result)
        
        print(f"  Observed {event_type}s: {len(observed_waits)}")
        print(f"  Bins used (k): {test_result.get('cutoff', '?')} -> {test_result['df'] + 2} categories, df = {test_result['df']}")
        print(f"  Chi-square: {test_result['chi2']:.4f}")
        print(f"  p-value: {test_result['p_value']:.4f}")
        print(f"  Cramér's V: {test_result['cramers_v']:.4f} ({test_result['effect_size']})")
        print(f"  Geometric pattern: {'YES' if test_result['p_value'] > 0.05 else ' NO'}")
    
    print("\n" + "="*70)
    print("SUMMARY")
    print("="*70)
    results_df = pd.DataFrame(all_results)
    print("\n", results_df[['group', 'n_innings', 'boundary_rate', 'df', 'p_value', 'cramers_v', 'effect_size', 'is_geometric']].to_string(index=False))
    
    geometric_groups = results_df[results_df['is_geometric'] == True]
    print(f"\nGroups showing geometric pattern: {len(geometric_groups)}/{len(results_df)}")
    
    print("\n" + "-"*70)
    print("NOTE ON CRAMER'S V")
    print("-"*70)
    print("The Cramer's V values reported here use the 1xk goodness-of-fit variant,")
    print("not the standard rxk contingency-table version. For a goodness-of-fit")
    print("test, the formula is V = sqrt(chi^2 / (n * (k-1))), where k is the number")
    print("of categories. This is appropriate for assessing how well observed")
    print("frequencies match a theoretical distribution (e.g., geometric).")
    
    print("\n" + "-"*70)
    print("STATISTICAL POWER CAVEAT")
    print("-"*70)
    valid_df = results_df.loc[results_df['df'] > 0, 'df']
    if len(valid_df) > 0:
        df_min, df_max = int(valid_df.min()), int(valid_df.max())
        df_desc = f"{df_min}" if df_min == df_max else f"{df_min}-{df_max}"
    else:
        df_desc = "a small number of"
    print(f"The chi-square tests within each group have only {df_desc} degree(s) of")
    print("freedom (compared to 7 in the pooled test), with roughly one-third the")
    print("sample size.\n")
    
    print("The tercile result itself has essentially no power to confirm or")
    print("rule out anything. 'Not rejected' here is close to uninformative.")
    
    return results, results_df

def save_results(results_df, filename):
    if len(results_df) > 0:
        filepath = OUTPUT_TABLES / filename
        results_df.to_csv(filepath, index=False)
        print(f"\n[OK] Results saved to: {filepath}")

def create_summary_table(innings_df, results_df):
    summary = {'metric': [], 'value': []}
    summary['metric'].append('Total innings')
    summary['value'].append(len(innings_df))
    for _, row in results_df.iterrows():
        summary['metric'].append(f"{row['group']} group - n")
        summary['value'].append(row['n_innings'])
        summary['metric'].append(f"{row['group']} group - rate (MLE)")
        summary['value'].append(f"{row['boundary_rate']:.6f}")
    return pd.DataFrame(summary)

def main():
    parser = argparse.ArgumentParser(description="Stratification Analysis")
    parser.add_argument("--n-groups", type=int, default=3, choices=[2,3,4,5])
    parser.add_argument("--event", type=str, default="boundary", choices=["boundary", "wicket"])
    parser.add_argument("--output", type=str, default=None)
    
    args = parser.parse_args()
    if args.output is None:
        args.output = f"stratification_{args.event}_results.csv"
    
    innings_df = load_innings_data()
    ball_data = load_ball_by_ball_data()
    innings_df['boundary_rate'] = compute_innings_boundary_rates(innings_df, ball_data)
    
    results, results_df = stratify_innings(innings_df, ball_data, n_groups=args.n_groups, event_type=args.event)
    
    save_results(results_df, args.output)
    summary_df = create_summary_table(innings_df, results_df)
    summary_path = OUTPUT_TABLES / f"stratification_summary_{args.event}.csv"
    summary_df.to_csv(summary_path, index=False)
    print(f"\n[OK] Summary saved to: {summary_path}")

if __name__ == "__main__":
    main()