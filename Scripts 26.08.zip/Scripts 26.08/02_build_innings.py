import numpy as np
import pandas as pd
from common import OUTPUT_TABLES, load_data, prepare_analysis_view

def first_event_record(group, event_col):
    positions = np.flatnonzero(group[event_col].to_numpy())
    if len(positions):
        i = int(positions[0])
        return int(i + 1), 1, group.iloc[i]["overs_category"]
    return int(len(group)), 0, np.nan

def main():
    # Re-read source independently: each script can run from a clean environment.
    df = load_data()
    legal = prepare_analysis_view(df)

    records = []
    for (match_id, innings_no), group in legal.groupby(
        ["match_id", "innings_no"], sort=False
    ):
        w_attempt, w_event, w_phase = first_event_record(group, "is_wicket")
        b_attempt, b_event, b_phase = first_event_record(group, "is_boundary")
        records.append({
            "match_id": match_id,
            "innings_no": innings_no,
            "batting_team": group["batting_team"].iloc[0],
            "first_wicket_attempt": w_attempt,
            "first_wicket_event": w_event,
            "first_wicket_phase": w_phase,
            "first_boundary_attempt": b_attempt,
            "first_boundary_event": b_event,
            "first_boundary_phase": b_phase,
            "total_legal_deliveries": len(group)
        })

    innings_df = pd.DataFrame(records)

    for event in ["first_wicket", "first_boundary"]:
        d = innings_df[f"{event}_attempt"]
        e = innings_df[f"{event}_event"]
        assert (d >= 1).all()
        assert e.isin([0, 1]).all()
        assert (d <= innings_df["total_legal_deliveries"]).all()

    innings_df.to_csv(OUTPUT_TABLES / "innings_survival_dataset.csv", index=False)

    print("=== INNINGS-LEVEL FIRST-EVENT DATA ===")
    print(f"Innings analysed: {len(innings_df):,}")
    print(f"First wicket observed: {innings_df.first_wicket_event.sum():,}")
    print(f"First boundary observed: {innings_df.first_boundary_event.sum():,}")
    print(f"No first wicket observed (censored): {(innings_df.first_wicket_event.eq(0)).sum():,}")
    print(f"No first boundary observed (censored): {(innings_df.first_boundary_event.eq(0)).sum():,}")

if __name__ == "__main__":
    main()
# At the end of main() in 02_build_innings.py, after the to_csv:
innings_df_check = pd.read_csv(OUTPUT_TABLES / "innings_survival_dataset.csv")
assert 'first_wicket_phase' in innings_df_check.columns
assert 'first_boundary_phase' in innings_df_check.columns
print("Verification: innings_survival_dataset.csv contains phase columns.")
